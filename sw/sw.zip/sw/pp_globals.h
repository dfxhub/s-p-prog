#pragma once

#define FILEIMAGE_LEN 70000
#define	PROGMEM_LEN	260000
#define	CONFIG_LEN	32
#define	CF_P16F_A	0
#define	CF_P18F_A	1
#define	CF_P16F_B	2
#define	CF_P18F_B	3
#define	CF_P18F_C	4
#define	CF_P18F_D	5
#define	CF_P18F_E	6
#define	CF_P16F_C	7
#define	CF_P16F_D	8
#define	CF_P18F_F	9
#define	CF_P18F_G	10
#define	CF_P18F_Q	11

typedef struct {
	unsigned char devid;
	int (*dev_func)(void);
} device_cmds_t;

extern char * COM;
extern int baudRate;
extern int verbose, verify, program, sleep_time, readflash, getmcuids;
extern int devid_expected, devid_mask, flash_size, page_size, chip_family, config_size;
extern unsigned char file_image[], config_bytes[];
